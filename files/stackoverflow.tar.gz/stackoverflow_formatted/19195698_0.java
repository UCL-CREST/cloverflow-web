ScheduledExecutorService scheduler =
    Executors.newSingleThreadScheduledExecutor();
private void repeat() {
    scheduler.scheduleAtFixedRate ( new Runnable() {
        @Override
        public void run() {
            new ReadBackgroundJSONFeedTask().execute ( "url" );
            Log.d ( "s", "json read!" );
        }
    }, 0, 1000, TimeUnit.MILLISECONDS );
}

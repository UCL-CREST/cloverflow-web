public void readFromFile ( String fileName, ListInterface<User> userList ) {
    String oneLine, oneLine2;
    User user;
    try {
        FileReader theFile = new FileReader ( fileName );
        BufferedReader fileIn = new BufferedReader ( theFile );
        oneLine = fileIn.readLine();
        while ( oneLine != null ) {
            oneLine2 = fileIn.readLine();
            user = new User ( oneLine, oneLine2 );
            oneLine = fileIn.readLine();
            userList.append ( user );
        }
        fileIn.close();
    } catch ( FileNotFoundException e ) {
        System.out.println ( "Unable to locate the file: " + fileName );
    } catch ( IOException e ) {
        System.out.println ( "There was a problem reading the file: "
                             + fileName );
    }
}
public void writeToFile ( String fileName, ListInterface<User> userList ) {
    try {
        FileWriter theFile = new FileWriter ( fileName );
        PrintWriter fileOut = new PrintWriter ( theFile );
        for ( int i = 1; i <= userList.size(); i++ ) {
            fileOut.println ( userList.get ( i ).getUsername() );
            fileOut.println ( userList.get ( i ).getPassword() );
        }
        fileOut.close();
    } catch ( IOException e ) {
        System.out.println ( "Problem writing to the file" );
    }
}

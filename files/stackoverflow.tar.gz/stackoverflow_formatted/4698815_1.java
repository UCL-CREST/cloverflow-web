Rpc.test ( attribute, new AsyncCallback<Boolean>() {
    @Override
    public void onSuccess ( Boolean result ) {
        if ( result ) {
        }
    }
    @Override
    public void onFailure ( Throwable caught ) {
        Window.alert ( caught.getMessage() );
    }
} );

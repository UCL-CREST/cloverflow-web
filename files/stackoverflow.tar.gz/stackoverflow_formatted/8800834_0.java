import static org.fest.assertions.Assertions.assertThat;
public class StudentTest {
    private final Student student = new StudentServiceImpl();
    @Test
    public void shouldReturnEmptyListOfStudentsWhenNotInitialized() {
        List<String> students = student.getStudentList();
        assertThat ( students ).isEmpty();
    }
    @Test
    public void shouldReturnSomeStudentsWhenListCreated() {
        student.createStudentList();
        List<String> students = student.getStudentList();
        assertThat ( students ).containsExactly ( "John", "Bill", "Ricky", "Jack" );
    }
    @Test
    public void shouldStorePreviouslySetListOfStudents() {
        student.setStudentList ( Arrays.asList ( "Jane", "Bob" ) );
        List<String> students = student.getStudentList();
        assertThat ( students ).containsExactly ( "Jane", "Bob" );
    }
}

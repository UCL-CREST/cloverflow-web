interface Mood {
    behave();
}
class GoodMood implements Mood {
    behave() {
    }
}
class AngryMood implements Mood {
    behave() {
    }
}
class Troll {
    doSomething ( Mood m ) {
        m.behave()
    }
}

public interface MyInterface {
    void setNumber ( int num );
    int getNumber();
}
public class MyClass implements MyInterface {
    private int number = 0;
    public void setNumber ( int num ) {
        this.number = num;
    }
    public void getNumber() {
        return this.number;
    }
}

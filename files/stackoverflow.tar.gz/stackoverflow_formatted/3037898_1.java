public long fibb() {
    List<Integer> list = new LinkedList<Integer>();
    list.add ( 1 );
    list.add ( 1 );
    while ( list.get ( 0 ) + list.get ( 1 ) < 4000000 ) {
        list.add ( 0, list.get ( 0 ) + list.get ( 1 ) );
    }
    long value = 0;
    for ( Integer n : list ) {
        if ( n % 2 == 0 ) {
            value += n;
        }
    }
    return value;
}

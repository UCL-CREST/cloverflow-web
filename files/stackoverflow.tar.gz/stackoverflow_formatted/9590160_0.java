HashSet<String> hs = new HashSet<String>();
int i = 0;
while ( ( line = br.readLine() ) != null ) {
    i++;
    if ( i % 4 == 0 ) {
        if ( hs.contains ( line ) )
            else {
                hs.add ( line );
            }
    }
}

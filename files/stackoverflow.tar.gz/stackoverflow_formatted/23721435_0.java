import java.util.*;
class Test {
    public static void main ( String[] args ) {
        Map<String, Object> x = new HashMap<>();
        x.put ( "foo", "bar" );
        x.put ( "number", 0 );
        Map<String, String> y = ( Map<String, String> ) ( Object ) x;
        System.out.println ( y.get ( "foo" ) );
        System.out.println ( y.get ( "number" ) );
    }
}

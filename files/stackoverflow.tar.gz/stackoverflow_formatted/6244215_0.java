@Autowired
InformationController informationController;
@RequestMapping ( ... )
public ModelAndView onSubmit ( ... ) {
    if ( loginsuccess ) {
        InformationModel informationModelObject = informationController.handleRequest ( ... );
        modelAndView.addObject ( "informationModel", informationModelObject );
        modelAndView.setView ( "frontPageView" );
    } else {
        modelAndView.setView ( "loginFailView" );
    }
    return modelAndView;
}

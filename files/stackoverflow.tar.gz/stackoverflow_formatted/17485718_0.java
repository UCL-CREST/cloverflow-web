import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
public class Buttons {
    public static void main ( String[] args ) {
        new Buttons();
    }
    public Buttons() {
        EventQueue.invokeLater ( new Runnable() {
            @Override
            public void run() {
                try {
                    UIManager.setLookAndFeel ( UIManager.getSystemLookAndFeelClassName() );
                } catch ( ClassNotFoundException ex ) {
                } catch ( InstantiationException ex ) {
                } catch ( IllegalAccessException ex ) {
                } catch ( UnsupportedLookAndFeelException ex ) {
                }
                JFrame frame = new JFrame ( "Test" );
                frame.setDefaultCloseOperation ( JFrame.EXIT_ON_CLOSE );
                frame.setLayout ( new BorderLayout() );
                frame.add ( new TestPane() );
                frame.pack();
                frame.setLocationRelativeTo ( null );
                frame.setVisible ( true );
            }
        } );
    }
    public class TestPane extends JPanel {
        public TestPane() {
            setLayout ( new GridBagLayout() );
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.gridwidth = GridBagConstraints.REMAINDER;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            add ( new JButton ( "I'm a very long button" ), gbc );
            add ( new JButton ( "I'm not" ), gbc );
        }
        @Override
        public Dimension getPreferredSize() {
            return new Dimension ( 200, 200 );
        }
    }
}

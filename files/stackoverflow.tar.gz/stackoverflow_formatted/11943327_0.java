@XmlType ( name = "requestStatus" )
@XmlEnum
public enum RequestStatus {
    SHIPPED,
    PENDING;
    public String value() {
        return name();
    }
    public static RequestStatus fromValue ( String v ) {
        return valueOf ( v );
    }
}

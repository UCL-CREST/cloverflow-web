Map<YourKey, YourValue> newMap = new HashMap<>();
for ( Map.EntrySet<YourKey, YourValue> entrySet : currentMap.entrySet() ) {
    if ( ... ) {
        YourValue newValue = ...;
        newMap.put ( entrySet.getKey(), newValue );
    }
}
for ( Map.EntrySet<YourKey, YourValue> entrySet : newMap.entrySet() ) {
    currentMap.put ( entrySet.getKey(), entrySet.getValue() );
}

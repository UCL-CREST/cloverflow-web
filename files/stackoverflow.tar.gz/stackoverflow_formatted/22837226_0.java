Calendar firingCal = Calendar.getInstance();
Calendar currentCal = Calendar.getInstance();
firingCal.set ( Calendar.HOUR_OF_DAY, 11 );
firingCal.set ( Calendar.MINUTE, 00 );
firingCal.set ( Calendar.SECOND, 00 );
long intendedTime = firingCal.getTimeInMillis();
long currentTime = currentCal.getTimeInMillis();
if ( intendedTime >= currentTime ) {
    alarmManager.setRepeating ( AlarmManager.RTC, intendedTime , AlarmManager.INTERVAL_DAY, pendingIntent );
} else {
    firingCal.add ( Calendar.DAY_OF_MONTH, 1 );
    intendedTime = firingCal.getTimeInMillis();
    alarmManager.setRepeating ( AlarmManager.RTC, intendedTime ,
                                AlarmManager.INTERVAL_DAY, pendingIntent );
}

@Override
public void buttonClicked ( View v ) {
    Fragment newFragment;
    if ( v.getId() == R.id.displayfragment1 ) {
        newFragment = new MyFragment();
    } else {
        newFragment = new MyFragment2();
    }
    FragmentTransaction transaction = fragmentManager.beginTransaction();
    transaction.replace ( R.id.myfragment, newFragment );
    transaction.addToBackStack ( null );
    transaction.commit();
}
};

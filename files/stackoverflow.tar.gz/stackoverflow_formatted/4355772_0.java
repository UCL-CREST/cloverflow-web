char[] hand = {'a', 'b', 'c', 'b', 'c'};
for ( int x = 0; x < hand.length - 1; x++ ) {
    for ( int y = ( x + 1 ); y < hand.length; y++ ) {
        if ( ( int ) hand[x] > ( int ) hand[y] ) {
            char temp = hand[y];
            hand[y] = hand[x];
            hand[x] = temp;
        }
    }
}
int score = 0;
for ( int x = 0; x < hand.length - 1; x++ ) {
    if ( hand[x] == hand[x + 1] ) {
        score++;
    }
}

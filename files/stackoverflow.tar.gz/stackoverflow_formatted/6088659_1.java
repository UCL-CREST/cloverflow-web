import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import javax.swing.*;
public class MvcView {
    private MvcControl control;
    private JTextField stateField = new JTextField ( 10 );
    private JPanel mainPanel = new JPanel();
    public MvcView ( MvcModel model ) {
        model.addPropertyChangeListener ( new PropertyChangeListener() {
            public void propertyChange ( PropertyChangeEvent evt ) {
                if ( evt.getPropertyName().equals ( MvcModel.STATE_PROP_NAME ) ) {
                    stateField.setText ( evt.getNewValue().toString() );
                }
            }
        } );
        JButton startButton = new JButton ( "Start" );
        startButton.addActionListener ( new ActionListener() {
            public void actionPerformed ( ActionEvent e ) {
                if ( control != null ) {
                    control.startButtonActionPerformed ( e );
                }
            }
        } );
        JButton endButton = new JButton ( "End" );
        endButton.addActionListener ( new ActionListener() {
            public void actionPerformed ( ActionEvent e ) {
                if ( control != null ) {
                    control.endButtonActionPerformed ( e );
                }
            }
        } );
        int gap = 10;
        JPanel buttonPanel = new JPanel ( new GridLayout ( 1, 0, gap, 0 ) );
        buttonPanel.add ( startButton );
        buttonPanel.add ( endButton );
        JPanel statePanel = new JPanel ( new FlowLayout ( FlowLayout.CENTER, 0, 0 ) );
        statePanel.add ( new JLabel ( "State:" ) );
        statePanel.add ( Box.createHorizontalStrut ( gap ) );
        statePanel.add ( stateField );
        mainPanel.setBorder ( BorderFactory.createEmptyBorder ( gap, gap, gap, gap ) );
        mainPanel.setLayout ( new BorderLayout ( gap, gap ) );
        mainPanel.add ( buttonPanel, BorderLayout.CENTER );
        mainPanel.add ( statePanel, BorderLayout.PAGE_END );
    }
    public void setGuiControl ( MvcControl control ) {
        this.control = control;
    }
    public JComponent getMainPanel() {
        return mainPanel;
    }
}

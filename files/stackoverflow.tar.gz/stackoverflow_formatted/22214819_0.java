public void switchPairs() {
    ListNode first = front;
    ListNode second = front.next;
    while ( first != null && second != null ) {
        int i = first.data;
        first.data = second.data;
        second.data = i;
        first = second.next;
        second = second.next.next;
    }
}

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
public class InnerMapSearch {
    public static void main ( String[] args ) {
        Map<String, HashMap<String, String>> outer_map = new HashMap<String, HashMap<String, String>>();
        Map<String, String> inner_map = new HashMap<String, String>();
        String[] searchParams = {"blabla1", "blabla3", "blabla20"};
        int reader = 1;
        while ( reader < 10 ) {
            String nameAsKey1 = "blabla" + reader;
            inner_map.put ( "name", nameAsKey1 );
            String surnameAsKey2 = "blabla" + reader;
            inner_map.put ( "surname", surnameAsKey2 );
            outer_map.put ( String.valueOf ( reader ), ( HashMap<String, String> ) inner_map );
            inner_map = new HashMap<String, String>();
            reader++;
        }
        Set<String> searchResults = new HashSet<String>();
        for ( String key : outer_map.keySet() ) {
            for ( Entry<String, String> innerEntry : outer_map.get ( key ).entrySet() ) {
                for ( String searchParam : searchParams ) {
                    if ( searchParam.equals ( innerEntry.getValue() ) ) {
                        searchResults.add ( searchParam );
                    }
                }
            }
        }
        String[] searchResultsArray = searchResults.toArray ( new String[searchResults.size()] );
    }
}

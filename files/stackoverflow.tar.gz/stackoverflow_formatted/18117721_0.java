Collections.sort ( asu, new Comparator<String>() {
    @Override
    public int compare ( String left, String right ) {
        int countCompare = counts.get ( left ).compareTo ( counts.get ( right ) ) );
        if ( countCompare != 0 ) {
        return countCompare;
    }
    return left.compareTo ( right );
}
} );

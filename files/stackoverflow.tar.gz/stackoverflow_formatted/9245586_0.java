private void pause() {
    if ( mp != null ) {
        mp.pause();
    }
}
private void stop() {
    if ( mp != null ) {
        mp.stop();
    }
}

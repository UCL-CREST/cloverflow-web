public static final int FLAG_1 = 1 << 0;
public static final int FLAG_2 = 1 << 1;
public static final int FLAG_3 = 1 << 2;
public static final int FLAG_4 = 1 << 3;
public void myFlagsFunction ( int flags ) {
    if ( 0 != ( flags & FLAG_1 ) ) {
    }
    if ( 0 != ( flags & FLAG_2 ) ) {
    }
}

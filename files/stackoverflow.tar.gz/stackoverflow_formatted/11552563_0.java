public final class PropertyManager {
    public static final PropertyManager INSTANCE = new PropertyManager();
    private static final Map<Property, Player> propertyListing = new HashMap<Property, Player>();
    public void buyProperty ( Player buyer, Property property ) {
        if ( propertyListing.containsKey ( property ) ) {
            throw new IllegalStateException ( "Unable to buy unless owner sells it" );
        }
        propertyListing.put ( property, buyer );
    }
    public void sellProperty ( Player seller, Player buyer, Property property ) {
        if ( !propertyListing.containsKey ( property ) ) {
            throw new IllegalStateException ( "Unable to sell Property which is not owned" );
        }
        Player owner = propertyListing.get ( property );
        if ( !owner.equals ( seller ) ) {
            throw new IllegalStateException ( "Unable to sell property seller doesn't own" );
        }
        propertyListing.put ( property, buyer );
    }
    public List<Property> getProperties ( Player owner ) {
    }
    @Nullable
    public Player getOwner ( Property property ) {
        return propertyListing.get ( property );
    }
    private PropertyManager() {
    }
}

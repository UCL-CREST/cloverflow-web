public class PageNode {
    public String title;
    public String url;
    public String toString() {
        return title;
    }
}
public class ChapterNode {
    public String title;
    public ArrayList<PageNode> pages = new ArrayList<PageNode>();
}

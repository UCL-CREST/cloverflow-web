Intent myintent = getIntent();
String[] activeURL = myintent.getStringArrayExtra ( "URL" );
List<String> titles = new ArrayList<String>();
for ( int i = 0; i < activeURL.length ; i++ ) {
    url = activeURL[i];
    messages.addAll ( new BaseFeedParser ( url ).parse() );
}
for ( Message msg : messages ) {
    titles.add ( msg.getTitle() );
}

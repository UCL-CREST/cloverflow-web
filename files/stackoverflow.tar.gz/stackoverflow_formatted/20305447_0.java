public class Question {
    private String label;
    private String option1;
    public String getLabel() {
        return label;
    }
    public void setLabel ( String label ) {
        this.label = label;
    }
}

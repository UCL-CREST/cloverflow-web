class Player {
    States currentState = States.STARTMENU;
    void doSomething() {
        switch ( currentState ) {
        case STARTMENU:
            ...;
        case PLAYERONEMENU:
            ...;
        }
    }
    void playMenu() {
        if ( currentState == States.PLAYMENU ) {
            ...
        }
    }
}

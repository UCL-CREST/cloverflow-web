public void SomeClass {
    private Object lock = new Object();
    private SomeState state;
    public void mutateSomeSharedState() {
        synchronized ( lock ) {
        }
    }
    public SomeState readState() {
        synchronized ( lock ) {
        }
    }
}

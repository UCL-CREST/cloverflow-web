js.addChangeListener ( new ChangeListener() {
    @Override
    public void stateChanged ( ChangeEvent e ) {
        if ( js.getValueIsAdjusting() ) {
            int num = ( int ) ( Math.rint ( ( double ) js.getValue() / 10 ) * 10 );
            tf.setText ( String.valueOf ( num ) );
        } else {
            tf.setText ( String.valueOf ( js.getValue() ) );
        }
    }
} );

public static Set<Currency> getAllCurrencies() {
    Set<Currency> toret = new HashSet<Currency>();
    Locale[] locs = Locale.getAvailableLocales();
    for ( Locale loc : locs ) {
        try {
            toret.add ( Currency.getInstance ( loc ) );
        } catch ( Exception exc ) {
        }
    }
    return toret;
}

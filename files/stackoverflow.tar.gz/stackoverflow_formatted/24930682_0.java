BroadcastReceiver receiver = new BroadcastReceiver() {
    @Override
    public void onReceive ( Context context, Intent intent ) {
        String action = intent.getAction();
        if ( DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals ( action ) ) {
        }
    }
};
registerReceiver ( receiver, new IntentFilter (
                       DownloadManager.ACTION_DOWNLOAD_COMPLETE ) );

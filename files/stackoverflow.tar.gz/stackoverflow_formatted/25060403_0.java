public static String findLauncherProviderAuthority ( Context context ) {
    final List<PackageInfo> packs = context.getPackageManager().getInstalledPackages ( PackageManager.GET_PROVIDERS );
    if ( packs == null ) {
        return null;
    }
    for ( PackageInfo pack : packs ) {
        final ProviderInfo[] providers = pack.providers;
        if ( providers == null ) {
            continue;
        }
        for ( ProviderInfo provider : providers ) {
            final String readPermission = provider.readPermission;
            final String writePermission = provider.writePermission;
            if ( readPermission != null && writePermission != null ) {
                final boolean readPermissionMatches = readPermission.startsWith ( "com.android." ) && readPermission.endsWith ( ".permission.READ_SETTINGS" );
                final boolean writePermissionMatches = writePermission.startsWith ( "com.android." ) && writePermission.endsWith ( ".permission.WRITE_SETTINGS" );
                if ( readPermissionMatches && writePermissionMatches ) {
                    return provider.authority;
                }
            }
        }
    }
    return null;
}

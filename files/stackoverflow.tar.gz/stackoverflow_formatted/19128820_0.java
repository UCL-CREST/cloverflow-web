for ( int i = 0; i < word.length(); i++ ) {
    if ( x < 0 || x >= puzzle.length || y < 0 || y >= puzzle[x].length ) {
        return false;
    }
    char c = word.charAt ( i );
    if ( puzzle[x][y] != c ) {
        return false;
    }
    x += offsetx;
    y += offsety;
}

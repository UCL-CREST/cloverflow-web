String param = "value";
File textFile = new File ( "/path/to/file.txt" );
File binaryFile = new File ( "/path/to/file.bin" );
String boundary = Long.toHexString ( System.currentTimeMillis() );
String CRLF = "\r\n";
URLConnection connection = new URL ( url ).openConnection();
connection.setDoOutput ( true );
connection.setRequestProperty ( "Content-Type", "multipart/form-data; boundary=" + boundary );
try (
        OutputStream output = connection.getOutputStream();
        PrintWriter writer = new PrintWriter ( new OutputStreamWriter ( output, charset ), true );
    ) {
    writer.append ( "--" + boundary ).append ( CRLF );
    writer.append ( "Content-Disposition: form-data; name=\"param\"" ).append ( CRLF );
    writer.append ( "Content-Type: text/plain; charset=" + charset ).append ( CRLF );
    writer.append ( CRLF ).append ( param ).append ( CRLF ).flush();
    writer.append ( "--" + boundary ).append ( CRLF );
    writer.append ( "Content-Disposition: form-data; name=\"textFile\"; filename=\"" + textFile.getName() + "\"" ).append ( CRLF );
    writer.append ( "Content-Type: text/plain; charset=" + charset ).append ( CRLF );
    writer.append ( CRLF ).flush();
    Files.copy ( textFile.toPath(), output );
    output.flush();
    writer.append ( CRLF ).flush();
    writer.append ( "--" + boundary ).append ( CRLF );
    writer.append ( "Content-Disposition: form-data; name=\"binaryFile\"; filename=\"" + binaryFile.getName() + "\"" ).append ( CRLF );
    writer.append ( "Content-Type: " + URLConnection.guessContentTypeFromName ( binaryFile.getName() ) ).append ( CRLF );
    writer.append ( "Content-Transfer-Encoding: binary" ).append ( CRLF );
    writer.append ( CRLF ).flush();
    Files.copy ( binaryFile.toPath(), output );
    output.flush();
    writer.append ( CRLF ).flush();
    writer.append ( "--" + boundary + "--" ).append ( CRLF ).flush();
}

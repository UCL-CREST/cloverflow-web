private void skipNextRowClick() {
    this.skipNextClickSelect = true;
}
private void rowClickSelect ( final TreeNode node ) {
    if ( this.skipNextClickSelect ) {
        this.skipNextClickSelect = false;
        return;
    }
    final boolean isSelected = Log4jPanel.this.treeTable.getTreeState().isNodeSelected ( node );
    treeTable.getTreeState().selectNode ( node, !isSelected );
}

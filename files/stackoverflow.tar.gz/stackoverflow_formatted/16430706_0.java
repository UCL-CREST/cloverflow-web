static boolean isPermutation ( char[] w, char[] k ) {
    int k_idx = 0;
    for ( w_idx = 0; w_idx < w.length; ++w_idx ) {
        if ( k_idx == k.length ) {
            return true;
        }
        if ( w[w_idx] > k[k_idx] ) {
            return false;
        }
        if ( w[w_idx] == k[k_idx] ) {
            ++k_idx;
        }
    }
    return k_idx == k.length;
}

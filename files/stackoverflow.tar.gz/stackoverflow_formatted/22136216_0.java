public static void main ( String[] args )
throws FileNotFoundException, IOException {
    processFile ( "words.txt" );
}
public static void processFile ( String filename ) throws FileNotFoundException, IOException {
    int[][] array = new int[4][3];
    int lineCount = 0;
    try ( BufferedReader br = new BufferedReader ( new FileReader ( filename ) ) ) {
        String line = br.readLine();
        while ( line != null ) {
            String[] parts = line.split ( " " );
            for ( int i = 0; i < parts.length; i++ ) {
                array[lineCount][i] = Integer.valueOf ( parts[i] );
            }
            lineCount++;
            line = br.readLine();
        }
    }
}

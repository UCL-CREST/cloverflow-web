final IndexedContainer container = new IndexedContainer();
container.addContainerProperty ( "Metadata Key", String.class, null );
container.addContainerProperty ( "Metadata Value", String.class, null );
int i = 0;
for ( String k : objectMetadatas.keySet() ) {
    Integer rowId = new Integer ( i );
    container.addItem ( rowId );
    container.getContainerProperty ( rowId, "Metadata Key" ).setValue ( k );
    container.getContainerProperty ( rowId, "Metadata Value" ).setValue ( objectMetadatas.get ( k ) );
    i++;
}
container.addListener ( new Property.ValueChangeListener() {
    public void valueChange ( ValueChangeEvent event ) {
        Property p = event.getProperty();
        System.out.println ( p );
    }
} );
buttonUpdate.addListener ( new Button.ClickListener() {
    public void buttonClick ( ClickEvent event ) {
        Map<String, String> map = new HashMap<String, String>();
        Collection i = tableMetadata.getContainerDataSource().getItemIds();
        for ( int x = 0; x < i.size(); x++ ) {
            Item it = myTable.getContainerDataSource().getItem ( x );
            String[] row = it.toString().split ( " " );
            map.put ( row[0], row[1] );
        }
    }
} );
tableMetadata.setContainerDataSource ( container );

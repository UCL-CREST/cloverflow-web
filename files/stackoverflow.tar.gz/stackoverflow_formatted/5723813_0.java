class IntArray {
    int[] myArray;
    public IntArray () {
        myArray = new int[0];
    }
    public IntArray ( int [] array ) {
        myArray = array;
    }
    public int[] getArray() {
        return myArray;
    }
    public int hashCode() {
        return Arrays.hashCode ( myArray );
    }
    public boolean equals ( Object o ) {
        if ( ! ( o instanceof IntArray ) ) {
            return false;
        }
        if ( o.myArray.length != myArray.length ) {
            return false;
        } else {
            for ( int i = 0; i < myArray.length; i++ ) {
                if ( myArray[i] != o.myArray[i] ) {
                    return false;
                }
            }
            return true;
        }
    }
}

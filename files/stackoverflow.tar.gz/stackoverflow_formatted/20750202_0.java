String[] values = new String[] { "Android", "iPhone", "WindowsMobile",
                                 "Blackberry", "WebOS", "Ubuntu", "Windows7", "Max OS X",
                                 "Linux", "OS/2", "Ubuntu", "Windows7", "Max OS X", "Linux",
                                 "OS/2", "Ubuntu", "Windows7", "Max OS X", "Linux", "OS/2",
                                 "Android", "iPhone", "WindowsMobile"
                               };
final ArrayList<String> list = new ArrayList<String>();
for ( int i = 0; i < values.length; ++i ) {
    list.add ( values[i] );
}

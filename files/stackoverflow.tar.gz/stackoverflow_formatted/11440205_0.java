public class TreeNode {
    public TreeNode() {
    }
    public TreeNode addNode ( String node, String... nodes ) {
        return this;
    }
    public TreeNode addNode ( TreeNode node, TreeNode... nodes ) {
        return this;
    }
}

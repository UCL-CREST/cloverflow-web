final View activityRootView = findViewById ( R.id.activityRoot );
activityRootView.getViewTreeObserver().addOnGlobalLayoutListener ( new OnGlobalLayoutListener() {
    @Override
    public void onGlobalLayout() {
        int heightDiff = activityRootView.getRootView().getHeight() - activityRootView.getHeight();
        if ( heightDiff > 100 ) {
            ... do something here
            }
    }
} );

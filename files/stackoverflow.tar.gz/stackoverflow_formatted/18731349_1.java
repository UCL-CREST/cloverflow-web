< bean id = "myDao" class = "com.MyDao" / >
                                <bean id = "myLogic" class = "com.MyLogic">
                                               < constructor - arg ref = "myDao" / > < !-- or other type of injection-- ?
                                                       < / bean >
                                                       < bean id = "myDao" class = "org.mockito.Mockito" factory - method = "mock" >
                                                                   < constructor - arg value = "com.MyDao" / >
                                                                           < / bean >
            @ContextConfiguration ( {
            "logicContext.xml", "test-logicContext.xml"
        } )
public class BaseLogicTest extends AbstractTestNGSpringContextTests {
    @Autowired
    private MyLogic myLogic;
    @Autowired
    private MyDao myDao;
    @Test
    @After public void clearMocks() {
        Mockito.reset ( myDao );
    }
}

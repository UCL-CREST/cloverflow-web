Collections.sort (
myList, new Comparator<String>() {
    @Override
    public int compare ( String a, String b ) {
        int aLastDash = a.lastIndexOf ( "-" );
        int bLastDash = b.lastIndexOf ( "-" );
        return a.substring ( aLastDash + 1 ).compareTo (
                   b.substring ( bLastDash + 1 ) );
    }
} );

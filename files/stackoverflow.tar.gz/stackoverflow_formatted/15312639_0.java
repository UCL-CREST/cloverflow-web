private static final ExecutorService executorService = Executors.newFixedThreadPool ( 1 );
public static void main ( String[] args ) {
    final Future<Object> future = executorService.submit ( new MyOtherWork() );
    final Object object;
    try {
        object = future.get();
    } catch ( InterruptedException ex ) {
        Thread.currentThread().interrupt();
    } catch ( ExecutionException ex ) {
    }
}
private static class MyOtherWork implements Callable<Object> {
    public Object call() throws Exception {
    }
}

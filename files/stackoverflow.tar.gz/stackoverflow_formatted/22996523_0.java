public class GFClass {
    public static void main ( String[] args ) {
        int a = 3, b = 4, n = 5;
        System.out.println ( GF ( a, b, n ) );
    }
    public static int GF ( int a, int b, int n ) {
        if ( n == 0 ) {
            return a % 1000000007;
        }
        if ( n == 1 ) {
            return b % 1000000007;
        }
        return ( GF ( a, b, n - 1 ) + GF ( a, b, n - 2 ) ) % 1000000007;
    }
}

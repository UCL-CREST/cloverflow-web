public void iterativePreorder ( Node root ) {
    iterativePreorderKernel ( root, root );
}
private void iterativePreorderKernel ( Node root, Node current ) {
    if ( current.left() != null ) {
        iterativePreorderKernel ( root, current.left() );
    }
    if ( current.right() != null ) {
        iterativePreorderKernel ( root, current.right() );
    }
    doCalculation ( root, current );
}
public void doCalculation ( Node innerCurrent, Node pretendLeaf ) {
    if ( innerCurrent != pretendLeaf ) {
        if ( innerCurrent.left() != null ) {
            doCalculation ( innerCurrent.left(), pretendLeaf );
        }
        if ( innerCurrent.right() != null ) {
            doCalculation ( innerCurrent.right(), pretendLeaf );
        }
    }
}

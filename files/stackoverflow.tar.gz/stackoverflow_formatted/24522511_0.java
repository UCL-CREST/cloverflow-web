int i = 0;
public void nextcard() {
    i++;
    if ( i >= QuesArray.length ) {
        i = 0;
    }
    questions.setText ( QuesArray[i] );
}
public void previousCard() {
    --i;
    if ( i < 0 ) {
        i = QuesArray.length - 1;
    }
    questions.setText ( QuesArray[i] );
}

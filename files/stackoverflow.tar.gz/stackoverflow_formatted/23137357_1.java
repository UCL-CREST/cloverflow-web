public class Main {
    final static String file = "Your file path";
    public static void main ( String[] args ) {
        final JTextField UserName = new JTextField ( "Enter Your UserName" );
        final JTextField Password = new JTextField ( "Enter Your Password" );
        JButton Login = new JButton ( "Login" );
        Login.addActionListener ( new ActionListener() {
            @Override
            public void actionPerformed ( ActionEvent arg0 ) {
                String uName = UserName.getText();
                String pass = Password.getText();
                checkUserPass ( uName, pass );
            }
        } );
    }
    static boolean checkUserPass ( String uName, String pass ) {
        try ( BufferedReader br = new BufferedReader ( new FileReader ( file ) ) ) {
            String line;
            if ( ( line = br.readLine() ) != null ) {
                String[] tmp = line.split ( ":" );
                if ( tmp[0].equals ( uName ) && tmp[1].equals ( pass ) ) {
                    return true;
                }
                return false;
            }
        } catch ( IOException e ) {
        }
        return false;
    }
}

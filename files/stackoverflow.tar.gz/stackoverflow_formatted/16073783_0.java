double width = highBound - lowBound;
double epsilon = .001;
double prevValue = -1.0;
double curValue = -1.0;
do {
    ...
    prevValue = curValue;
    curValue = sumOfArea;
    width /= 2.0;
} while ( Math.abs ( prevValue - curValue ) > epsilon );

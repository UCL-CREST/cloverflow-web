Request URL: https:
Request Method: POST
Cookie: SaveStateCookie = undefined % 2Ccom.ibm.team.workitem.category % 2Ccom.ibm.teamz.dsdef.category % 2Ccom.ibm.team.dashboard.category % 2Ccom.ibm.team.dashboard.category~ % 23_~ % 23com.ibm.team.dashboard.server.saveTeamDashboard;
JSESSIONID = BF3DA3D5E0FCA16193876307E91A5471;
JazzFormAuth = Form;
net - jazz - ajax - cookie - rememberUserId = VonC;
JSESSIONIDSSO = 05626E20EC4F6DB231759EFC4DB69785
                Host: jazzServer
                Origin: https:
                Referer: https:
                Form Dataview URL encoded
{"propertyRequest": {"jazz_scm:lastModified": null, "jazz_scm:creator": {"dcterms:name,rdf:resource": null}, "jazz_scm:reasons": {"dcterms:title,rdf:resource": null}, "jazz_scm:relatedArtifacts": {"dcterms:title,dcterms:description,rdf:resource,jazz_scm:linkTypeId,oslc_scm:mimeType": null}}}:

char * sprintfDouble ( char * buf, double v, const char * floatFormat, const char * sciFormat, double thresholdLow, double thresholdHigh ) {
    char * p;
    char * pd;
    char * pe;
    char * buforig;
    int trimmed;
    if ( v != v ) {
        sprintf ( buf, "NaN" );
        return buf;
    }
    if ( v == v && ( v - v ) != 0.0 ) {
        sprintf ( buf, v <  0 ? "-Infinity" : "Infinity" );
        return buf;
    }
    if ( v == 0 ) {
        sprintf ( buf, "0.0" );
        return buf;
    }
    buforig = buf;
    if ( v < 0 ) {
        v = -v;
        buf[0] = '-';
        buf++;
    }
    if ( v > thresholdLow && v < thresholdHigh ) {
        sprintf ( buf, floatFormat, v );
        pe = buf + strlen ( buf );
        pd = ( char * ) strchr ( buf, '.' );
        if ( pd == NULL ) {
            pd = pe;
            * pe++ = '.';
            * pe++ = '0';
            * pe = 0;
        }
    } else {
        sprintf ( buf, sciFormat, v );
        pe  = ( char * ) strchr ( buf, 'e' );
        pd = ( char * ) strchr ( buf, '.' );
        if ( pd == NULL ) {
            p = buf + strlen ( buf );
            while ( p >= pe ) {
                * p = * ( p - 2 );
                p--;
            }
            pd = pe;
            * pe++ = '.';
            * pe++ = '0';
            * pe = 0;
        }
        if ( ( * ( pe + 2 ) == '0' ) && ( strlen ( buf ) - ( pe - buf ) ) == 5 ) {
            * ( pe + 2 ) = * ( pe + 3 );
            * ( pe + 3 ) = * ( pe + 4 );
            * ( pe + 4 ) = * ( pe + 5 );
        }
    }
    trimmed = 0;
    p = pe - 1;
    while ( * p == '0' ) {
        p--;
        trimmed++;
    }
    if ( * p == '.' ) {
        trimmed--;
        p++;
    }
    if ( trimmed > 0 ) {
        p = pe;
        while ( 1 ) {
            * ( p - trimmed ) = * p;
            if ( * p == 0 ) {
                break;
            }
            p++;
        }
    }
    return buforig;
}
char * sprintfDouble5 ( char * buf, double v ) {
    return sprintfDouble ( buf, v, "%.5f", "%.5e", 0.01, 1000000.0 );
}

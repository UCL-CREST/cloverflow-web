def uploadFile() =
Action ( parse.multipartFormData ( myPartHandler ) ) {
    request => Ok ( "Done" )
}
def myPartHandler: BodyParsers.parse.Multipart.PartHandler[MultipartFormData.FilePart[Result]] = {
    parse.Multipart.handleFilePart {
    case parse.Multipart.FileInfo ( partName, filename, contentType ) =>
            String path = partName;
        val pos: PipedOutputStream = new PipedOutputStream();
        val pis: PipedInputStream  = new PipedInputStream ( pos );
        val worker: UploadFileWorker = new UploadFileWorker ( path, pis );
        worker.contentType = contentType.get;
        worker.start();
        Iteratee.fold[Array[Byte], PipedOutputStream] ( pos ) {
            ( os, data ) =>
            os.write ( data )
            os
        } .mapDone {
            os =>
            os.close()
            Ok ( "upload done" )
        }
    }
}

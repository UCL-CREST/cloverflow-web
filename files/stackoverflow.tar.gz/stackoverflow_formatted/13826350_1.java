ZipOutputStream zipOut = ...
                         zipOut.setMethod ( ZipOutputStream.STORED );
for ( int i = 0; i < tableModel.getRowCount(); i++ ) {
    File originalFile = ( File ) tableModel.getValueAt ( i, 0 );
    FileInputStream originalStream = new FileInputStream ( originalFile );
    GZipOutputStream gzipOut = ...;
    ...
    InputStream gzipResultIn = ...
                               ZipEntry zipEntry = new ZipEntry ( originalFile.getName()
                                       + ".gz.enc" );
    zipOut.putNextEntry ( zipEntry );
    encrypt ( key, gzipResultIn, zipOut );
    zipOut.closeEntry();
}
zipOut.close();

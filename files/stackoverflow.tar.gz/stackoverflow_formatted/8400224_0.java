public class PhoneBook {
    private Phone homePhone;
    private Phone officePhone;
    private Phone mobilePhone;
    private List<Phone> otherPhones;
    ..getters / setters..
}
public class Phone {
    private String phone;
    private String description;
    ..getters / setters..
}

public static String getCommandOutput ( String command )  {
    String output = null;
    Process process = null;
    BufferedReader reader = null;
    InputStreamReader streamReader = null;
    InputStream stream = null;
    try {
        process = Runtime.getRuntime().exec ( command );
        stream = process.getInputStream();
        streamReader = new InputStreamReader ( stream );
        reader = new BufferedReader ( streamReader );
        String currentLine = null;
        StringBuilder commandOutput = new StringBuilder();
        while ( ( currentLine = reader.readLine() ) != null ) {
            commandOutput.append ( currentLine + "\n" );
        }
        int returnCode = process.waitFor();
        if ( returnCode == 0 ) {
            output = commandOutput.toString();
        }
    } catch ( IOException e ) {
        System.err.println ( "Cannot retrieve output of command" );
        System.err.println ( e );
        output = null;
    } catch ( InterruptedException e ) {
        System.err.println ( "Cannot retrieve output of command" );
        System.err.println ( e );
    } finally {
        if ( stream != null ) {
            try {
                stream.close();
            } catch ( IOException e ) {
                System.err.println ( "Cannot close stream input! " + e );
            }
        }
        if ( streamReader != null ) {
            try {
                streamReader.close();
            } catch ( IOException e ) {
                System.err.println ( "Cannot close stream input reader! " + e );
            }
        }
        if ( reader != null ) {
            try {
                streamReader.close();
            } catch ( IOException e ) {
                System.err.println ( "Cannot close stream input reader! " + e );
            }
        }
    }
    return output;
}

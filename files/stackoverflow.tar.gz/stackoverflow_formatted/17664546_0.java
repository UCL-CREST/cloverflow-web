public enum MyEnum {
    Alpha,
    Bravo,
    Charlie {
        @Override
        public MyEnum next() {
            return null;
        };
    };
    public MyEnum next() {
        return values() [ordinal() + 1];
    }
}

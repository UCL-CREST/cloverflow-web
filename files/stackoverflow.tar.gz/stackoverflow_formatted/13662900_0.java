Scanner input = new Scanner ( System.in );
while ( input.hasNextLine() ) {
    char [] name = new char[10];
    String firstName = input.next();
    for ( int j = 0; j < firstName.length(); j++ ) {
        name [j] = firstName.charAt ( j );
    }
    for ( int i = 0; i < name.length; i++ ) {
        System.out.println ( name );
    }
    long ssn = input.nextLong();
    System.out.println ( ssn );
    double[] grades = new double[4];
    grades[0] = input.nextDouble();
    System.out.println ( grades[0] );
    grades[1] = input.nextDouble();
    System.out.println ( grades[1] );
    grades[2] = input.nextDouble();
    System.out.println ( grades[2] );
    grades[3] = input.nextDouble();
    System.out.println ( grades[3] );
    input.nextLine();
}
input.close();

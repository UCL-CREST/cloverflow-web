template< class Key,
    class T,
        class Comparator,
            class MapAllocator,
                class SeqAllocator,
                    template<class, class> class Sequence>
                            void make_key_set ( const std::map<Key, T, Comparator, MapAllocator> & map,
                                                Sequence<Key, SeqAllocator> & sequence ) {
                            sequence.clear();
                            typedef typename std::map<Key, T, Comparator, MapAllocator> map_type;
                            typename map_type::const_iterator itr = map.begin();
                            while ( map.end() != itr ) {
                                sequence.push_back ( ( itr++ )->first );
                            }
                        }

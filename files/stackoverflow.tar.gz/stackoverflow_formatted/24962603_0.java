private String aaPage;
private String aPage;
private String aPa;
private String aP;
private String a;
public void setAaPage ( String aaPage ) {
    this.aaPage = aaPage;
}
public void setAPage ( String page ) {
    aPage = page;
}
public void setAPa ( String pa ) {
    aPa = pa;
}
public void setAP ( String ap ) {
    aP = ap;
}
public void setA ( String a ) {
    this.a = a;
}

import java.util.Calendar;
import java.util.Date;
public class CompareDates {
    public static void main ( String[] args ) {
        Calendar cal = Calendar.getInstance();
        cal.add ( Calendar.DATE, -1 );
        System.out.println ( dateCompare ( new Date(), cal.getTime() ) );
        cal.add ( Calendar.DATE, 2 );
        System.out.println ( dateCompare ( new Date(), cal.getTime() ) );
    }
    public static int dateCompare ( Date today, Date date2 ) {
        System.out.println ( "Compare " + today + " with " + date2 );
        return today.compareTo ( date2 );
    }
}

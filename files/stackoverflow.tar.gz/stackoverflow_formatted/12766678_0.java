public void remove ( int n ) {
    LinkEntry<E> remove_this = new LinkEntry<E>();
    int i = 0;
    boolean removed = false;
    remove_this = head;
    while ( removed == false ) {
        if ( remove_this.previous == null ) {
            head = remove_this.next;
            head.previous = null;
            removed = true;
        } else if ( remove_this.next == null ) {
            tail = remove_this.previous;
            tail.next = null;
            removed = true;
        } else {
            if ( i == n ) {
                remove_this.previous.next = remove_this.next;
                remove_this.next.previous = remove_this.previous;
                removed = true;
                break;
            }
        }
        if ( !removed ) {
            remove_this = remove_this.next;
        }
        i++;
    }
}

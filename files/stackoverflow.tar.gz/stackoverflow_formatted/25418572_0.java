LocationManager locationManager = ( LocationManager ) getSystemService ( LOCATION_SERVICE );
locationManager.requestLocationUpdates ( LocationManager.GPS_PROVIDER, 1000L, 1.0f, this );
boolean isGPS = locationManager.isProviderEnabled ( LocationManager.GPS_PROVIDER );
if ( isGPS ) {
    String locationProvider = LocationManager.GPS_PROVIDER;
    locationManager.requestLocationUpdates ( locationProvider, 400, 1, this );
    Location loc =   locationManager.getLastKnownLocation ( LocationManager.GPS_PROVIDER );
    if ( loc != null ) {
        viewlocation = ( TextView ) findViewById ( R.id.location );
        viewlocation.setText ( "My Current location \n Latitude = " + loc.getLatitude() + " \n Longitude = " + loc.getLongitude() );
    }
} else {
    startActivityForResult ( new Intent ( android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS ), 0 );
}

private int[] a;
public void plus ( final int[] b ) {
    assert b != null;
    if ( a.length < b.length ) {
        final int[] newA = new int[b.length];
        System.arraycopy ( a, 0, newA, 0, a.length );
        a = newA;
    }
    for ( int i = 0; i < b.length; i++ ) {
        a[i] = a[i] + b[i];
    }
}

int oldIndex = 0;
int length = input.length();
for ( int i = 0 ; i < length; i ++ ) {
    if ( input.charAt ( i ) == ' ' || i == length - 1 ) {
        String check = ( i == length - 1 ) ? input.substring ( oldIndex ) :
                       input.substring ( oldIndex, i );
        oldIndex = i + 1;
        if ( check.length() >= wordlength ) {
            count++;
        }
    }
}

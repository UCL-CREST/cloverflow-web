public class Foo {
    public void wash ( Apple a ) {
        System.out.println ( "Apple" ) ;
    }
    public void wash ( Peach p ) {
        System.out.println ( "Peach" ) ;
    }
    public void bar ( List<? extends Fruit> arguments ) {
        FruitVisitor fv = new FruitVisitor() {
            public void visit ( Apple a ) {
                wash ( a ) ;
            }
            public void visit ( Peach p ) {
                wash ( p ) ;
            }
        } ;
        for ( Fruit f : arguments ) {
            f.accept ( fv ) ;
        }
    }
}

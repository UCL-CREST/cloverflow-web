public class Foo {
    private Map<String, Bar> barDictionary;
    public Foo() {
        this.barDictionary = new HashMap<String, Bar>();
    }
    public Foo ( Foo f ) {
        this.barDictionary = new HashMap<String, Bar>();
        this.barDictionary.putAll ( f.barDictionary );
    }
}

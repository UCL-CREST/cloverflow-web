if ( prev_event.equalsIgnoreCase ( plus ) ) {
    a = a + Float.parseFloat ( textField1.getText() );
} else if ( prev_event.equalsIgnoreCase ( minus ) ) {
    a = a - Float.parseFloat ( textField1.getText() );
} else if ( prev_event.equalsIgnoreCase ( multiply ) ) {
    a = a * Float.parseFloat ( textField1.getText() );
} else if ( prev_event.equalsIgnoreCase ( divide ) ) {
    a = a / Float.parseFloat ( textField1.getText() );
}
prev_event = "-";
textField3.setText ( Float.toString ( a ) );

final String nameIn = scan.next();
final id[] namesFinal = names;
final Integer[] sortedIndices = new Integer[names.length];
for ( int i = 0; i < sortedIndices.length; i++ ) {
    sortedIndices[i] = i;
}
Arrays.sort ( sortedIndices, 0, names.length, new Comparator<Integer>() {
    @Override
    public int compare ( Integer o1, Integer o2 ) {
        String name1 = namesFinal[o1].name;
        String name2 = namesFinal[o2].name;
        int name1Distance = levenshteinDistance ( name1, nameIn );
        int name2Distance = levenshteinDistance ( name2, nameIn );
        return name1Distance - name2Distance;
    }
} );

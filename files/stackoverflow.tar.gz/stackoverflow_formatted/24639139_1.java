public class Test1 {
    static WebDriver driver;
    @Test
    public void test1() {
        driver = BaseTest.driver;
    }
}
public class Test2 {
    static WebDriver driver;
    @Test
    public void test2() {
        driver = BaseTest.driver;
    }
}

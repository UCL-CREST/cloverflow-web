public class MyActivity extends Activity {
    public interface AsyncTaskCompleteListener {
        public void onComplete ( );
    }
    ...
    private AsyncTaskCompleteListener myListener = new ...() {
    }
    private MyAsyncTask extends AsyncTask<Something, Something, Something> {
        private AsyncTaskCompleteListener listener = null;
        public MyAsyncTask ( AsyncTaskCompleteListener listener ) {
            this.listener = listener;
        }
        protected void onPostExecute ( Something result ) {
            if ( listener != null ) {
                listener.onComplete ( );
            }
        }
    }
    ...
}

package p1;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
public class BlockBuster {
    private List<Block> queue;
    private List<Block> bustList;
    public BlockBuster() {
        queue = new ArrayList<Block>();
    }
    public void bustBlocks() {
        Block block = BlockManager.getInstance().getFallingBlock();
        bustList = new ArrayList<Block>();
        queue.add ( block );
        while ( queue.size() > 0 ) {
            Block current = queue.get ( 0 );
            addMatchingNeighbors ( current );
            queue.remove ( 0 );
            if ( !bustList.contains ( current ) ) {
                bustList.add ( current );
            }
        }
        if ( bustList.size() > 2 ) {
            for ( Block busted : bustList ) {
                BlockManager.getInstance().RemoveBlock ( busted );
                List<Block> check = BlockManager.getInstance().getAllBlocks();
                if ( check.contains ( busted ) ) {
                    boolean stop = true;
                }
            }
        }
    }
    private void addMatchingNeighbors ( Block block ) {
        int x = block.getColumn();
        int y = block.getLevel();
        Color color = block.getColor();
        Block leftBlock = getBlock ( x - 1, y );
        if ( colorMatches ( color, leftBlock ) ) {
            queue.add ( leftBlock );
        }
        Block rightBlock = getBlock ( x + 1, y );
        if ( colorMatches ( color, rightBlock ) ) {
            queue.add ( rightBlock );
        }
        Block upBlock = getBlock ( x, y + 1 );
        if ( colorMatches ( color, upBlock ) ) {
            queue.add ( upBlock );
        }
        Block downBlock = getBlock ( x, y - 1 );
        if ( colorMatches ( color, downBlock ) ) {
            queue.add ( downBlock );
        }
    }
    public boolean colorMatches ( Color color, Block block ) {
        if ( block == null ) {
            return false;
        }
        if ( bustList.contains ( block ) ) {
            return false;
        }
        if ( queue.contains ( block ) ) {
            return false;
        }
        return ( block.getColor().equals ( color ) );
    }
    public Block getBlock ( int column, int level ) {
        Column[] columns = BlockManager.getInstance().getColumns();
        if ( column >= 0 && column < 10 ) {
            if ( columns[column].getBlocks().size() > level && level >= 0 ) {
                Block result = columns[column].getBlocks().get ( level );
                if ( bustList.contains ( result ) ) {
                    return null;
                }
                return result;
            }
        }
        return null;
    }
}

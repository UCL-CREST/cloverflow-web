public class MyOwnTransformer implements ResultTransformer {
    @Override
    public Dog transformTuple ( Object[]data, String[]alias ) {
        return new Dog ( ( Integer ) data[0], new Owner ( ( Integer ) data[1] ) );
    }
    @Override
    public List transformList ( List dogs ) {
        return dogs;
    }
}

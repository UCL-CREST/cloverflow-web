Class myListActivity extends Activity {
    ... some code here...
    public void onCreate ( Bundle savedInstanceState ) {
        .....
        myList.setAdapter ( new myCustomAdapter() );
        .....
    }
    class myCustomAdapter extends BaseAdapter{
        TextView userName;
        @Override
        public int getCount() {
            return DataArr.length;
        }
        @Override
        public String getItem ( int position ) {
            return null;
        }
        @Override
        public long getItemId ( int position ) {
            return position;
        }
        @Override
        public View getView ( int position, View convertView, ViewGroup parent ) {
            View row = convertView;
            final int pos = position;
            if ( row == null ) {
                LayoutInflater inflater = getLayoutInflater();
                row = inflater.inflate ( R.layout.list_row, parent, false );
            }
            userName = ( TextView ) row.findViewById ( R.id.user_name );
            userName.setText ( DataArr[position] );
            return row;
        }
    }
}

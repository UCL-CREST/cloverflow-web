ip = "";
builder = new AlertDialog.Builder ( this );
builder.setView ( dialoglayout );
builder.setPositiveButton ( "Yes",
new DialogInterface.OnClickListener() {
    @Override
    public void onClick ( DialogInterface dialog, int id ) {
        EditText text = ( EditText ) dialoglayout
                        .findViewById ( R.id.et_gamerIpOrWebAdress );
        ip = text.getText().toString();
        if ( !ip.equals ( "" ) ) {
            new GamerWorker().execute ( ip );
            intent = new Intent ( MainActivity.this, BroadcastService.class );
        }
    }
} );
builder.setNegativeButton ( "No",
new DialogInterface.OnClickListener() {
    @Override
    public void onClick ( DialogInterface dialog, int id ) {
        dialog.dismiss();
    }
} );
if ( ip.equals ( "" ) && ip.isEmpty() ) {
    AlertDialog dialog = builder.create();
    dialog.show();
} else {
    new GamerWorker().execute ( ip );
    intent = new Intent ( MainActivity.this, BroadcastService.class );
}
}

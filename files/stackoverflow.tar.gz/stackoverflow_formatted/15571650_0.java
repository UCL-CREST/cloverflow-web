import com.amazonaws.AmazonWebServiceRequest;
import com.amazonaws.HttpMethod;
import com.amazonaws.Request;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.handlers.RequestHandler;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.Headers;
import com.amazonaws.services.s3.internal.S3QueryStringSigner;
import com.amazonaws.services.s3.internal.ServiceUtils;
import java.util.Date;
public class PrettyUrlS3Client extends AmazonS3Client {
    private AWSCredentials awsCredentials;
    public PrettyUrlS3Client ( AWSCredentials awsCredentials ) {
        super ( awsCredentials );
        this.awsCredentials = awsCredentials;
    }
    @Override
    protected <T> void presignRequest ( Request<T> request, HttpMethod methodName, String bucketName, String key, Date expiration, String subResource ) {
        if ( requestHandlers != null ) {
            for ( RequestHandler requestHandler : requestHandlers ) {
                requestHandler.beforeRequest ( request );
            }
        }
        String resourcePath = "/" +
                              ( ( bucketName != null ) ? bucketName + "/" : "" ) +
                              ( ( key != null ) ? keyToEscapedPath ( key )   : "" ) +
                              ( ( subResource != null ) ? "?" + subResource : "" );
        request.setResourcePath ( resourcePath.substring ( 1 ) );
        AWSCredentials credentials = awsCredentials;
        AmazonWebServiceRequest originalRequest = request.getOriginalRequest();
        if ( originalRequest != null && originalRequest.getRequestCredentials() != null ) {
            credentials = originalRequest.getRequestCredentials();
        }
        new S3QueryStringSigner<T> ( methodName.toString(), resourcePath, expiration ).sign ( request, credentials );
        if ( request.getHeaders().containsKey ( Headers.SECURITY_TOKEN ) ) {
            String value = request.getHeaders().get ( Headers.SECURITY_TOKEN );
            request.addParameter ( Headers.SECURITY_TOKEN, value );
            request.getHeaders().remove ( Headers.SECURITY_TOKEN );
        }
    }
    public static String keyToEscapedPath ( String key ) {
        String[] keyParts = key.split ( "/" );
        StringBuilder result = new StringBuilder();
        for ( String part : keyParts ) {
            if ( result.length() > 0 ) {
                result.append ( "/" );
            }
            result.append ( ServiceUtils.urlEncode ( part ) );
        }
        return result.toString().replaceAll ( "%7E", "~" );
    }
}

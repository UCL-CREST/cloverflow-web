public abstract class Event {
    @DatabaseField ( columnName = "id", generatedId = true )
    protected int _id;
    @DatabaseField ( columnName = "name" )
    protected String name;
    @DatabaseField ( columnName = "date" )
    protected Date date;
    @DatabaseField ( columnName = "type" )
    protected String type;
    public abstract void setName ( String name );
    public abstract void setDate ( Date date );
    public abstract void setType ( String type );
}

while ( true ) {
    try {
        Thread.sleep ( 20 );
    } catch ( InterruptedException e ) {
        e.printStackTrace();
    }
    try {
        clientSocket = serverSocket.accept();
        ...
    }
    ...
}

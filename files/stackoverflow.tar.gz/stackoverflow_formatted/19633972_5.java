<div id = "cbTree"> < / div >
          <script type = "text/javascript">
$ ( function() {
    $ ( "#cbTree" ).dynatree ( {
        initAjax: {
            url: / CourtBranch / LoadTreeView
        },
        checkbox: true,
        selectMode: 3
    } );
} );
< / script >

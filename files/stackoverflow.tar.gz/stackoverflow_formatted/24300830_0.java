public abstract class Test {
    public Test() {
        System.out.println ( "foo" );
    }
    public static class SubTest extends Test {
    }
    public static void main ( String[] args ) throws Exception {
        Test foo = new Test();
        SubTest bar = new SubTest();
    }
}

import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.List;
public class RectGroup extends ArrayList<Rectangle> implements List<Rectangle> {
    public RectGroup ( Rectangle... rects ) {
        super ( rects );
    }
    public RectGroup() {
        super();
    }
    public boolean intersects ( Rectangle rect ) {
        for ( Rectangle r : this )
            if ( rect.intersects ( r ) ) {
                return true;
            }
        return false;
    }
    public List<RectGroup> getDistinctGroups() {
        List<RectGroup> groups = new ArrayList<RectGroup>();
        for ( Rectangle newRect : this ) {
            List<RectGroup> newGroupings = new ArrayList<RectGroup>();
            for ( RectGroup group : groups )
                if ( group.intersects ( newRect ) ) {
                    newGroupings.add ( group );
                }
            RectGroup newGroup = new RectGroup ( newRect );
            for ( List<Rectangle> oldGroup : newGroupings ) {
                groups.remove ( oldGroup );
                newGroup.addAll ( oldGroup );
            }
            groups.add ( newGroup );
        }
        return groups;
    }
}
